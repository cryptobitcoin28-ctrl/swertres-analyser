SWERTRES PROBABLES ANALYSER V3.0 — MOBILE PWA

1. Extract this ZIP.
2. Create a PUBLIC GitHub repository and upload index.html, app.js, manifest.webmanifest, service-worker.js and the icons folder (preserve paths).
3. In repository Settings > Pages, choose Deploy from a branch, main branch, root folder, then Save.
4. Open the HTTPS GitHub Pages address on Android Chrome.
5. Use Chrome menu > Install app / Add to Home screen.
6. Open the app once online so the files are cached for offline use.

Notes:
- All draw history is stored locally in the browser/app. Export CSV regularly to back it up.
- Browser data clearing or uninstalling may erase history.
- Formula calculations preserve the original matching method. Formula Stats coverage now counts actual permutations out of 1,000 possible results.
- No lottery formula guarantees winning results.
